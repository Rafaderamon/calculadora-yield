
import React, { useState } from "react";

export default function YieldCalculator() {
  const [purchasePrice, setPurchasePrice] = useState(0);
  const [capex, setCapex] = useState(0);
  const [squareMeters, setSquareMeters] = useState(0);
  const [targetYield, setTargetYield] = useState(6);
  const [exitYield, setExitYield] = useState(4.5);

  const totalCost = purchasePrice + capex;
  const annualRentRequired = (totalCost * targetYield) / 100;
  const rentPerM2PerMonth = squareMeters
    ? annualRentRequired / 12 / squareMeters
    : 0;
  const estimatedSalePrice = annualRentRequired / (exitYield / 100);
  const grossProfit = estimatedSalePrice - totalCost;
  const projectReturn = totalCost ? (grossProfit / totalCost) * 100 : 0;

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: 'auto' }}>
      <h1>Calculadora de Yield y Venta</h1>
      <div>
        <label>Precio de compra (€)</label>
        <input type="number" value={purchasePrice} onChange={(e) => setPurchasePrice(parseFloat(e.target.value))} />
      </div>
      <div>
        <label>CAPEX (€)</label>
        <input type="number" value={capex} onChange={(e) => setCapex(parseFloat(e.target.value))} />
      </div>
      <div>
        <label>Metros cuadrados</label>
        <input type="number" value={squareMeters} onChange={(e) => setSquareMeters(parseFloat(e.target.value))} />
      </div>
      <div>
        <label>Rentabilidad deseada (%)</label>
        <input type="number" value={targetYield} onChange={(e) => setTargetYield(parseFloat(e.target.value))} />
      </div>
      <div>
        <label>Yield futura estimada (%)</label>
        <input type="number" value={exitYield} onChange={(e) => setExitYield(parseFloat(e.target.value))} />
      </div>
      <hr />
      <div><strong>Coste total:</strong> €{totalCost.toFixed(2)}</div>
      <div><strong>Ingreso anual necesario:</strong> €{annualRentRequired.toFixed(2)}</div>
      <div><strong>Alquiler por m²/mes:</strong> €{rentPerM2PerMonth.toFixed(2)}</div>
      <div><strong>Precio de venta estimado:</strong> €{estimatedSalePrice.toFixed(2)}</div>
      <div><strong>Beneficio estimado:</strong> €{grossProfit.toFixed(2)}</div>
      <div><strong>Rentabilidad total:</strong> {projectReturn.toFixed(2)}%</div>
    </div>
  );
}
